package com.remp.work.model.service;

/**
 * <p>
 * Eis를 위한 Service
 * </p>
 * @author 이동훈, 김재림, 이원호, 이민정
 * @since JDK 1.8 이후, Spring F/W 3.2.12이후
 * @version ReMP v 1.0
 */
public interface EisService {

}
